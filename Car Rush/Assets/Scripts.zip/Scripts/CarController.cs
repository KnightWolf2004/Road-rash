using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    [SerializeField]
    private float _carSpeed;
    Vector3 carPosition;
    [SerializeField]
    private float _maxLeft;
    [SerializeField]
    private float _maxRight;

    public GameObject road;
    private Road _roadScript;

    // Start is called before the first frame update
    void Start()
    {
        carPosition = transform.position;
        _roadScript = road.GetComponent<Road>();
        
    }

    // Update is called once per frame
    void Update()
    {
        carPosition.x += Input.GetAxis("Horizontal") * _carSpeed * Time.deltaTime;
        carPosition.x = Mathf.Clamp(carPosition.x, _maxLeft, _maxRight);
        transform.position = carPosition;
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Enemy")
        {
            _roadScript._scrollSpeed = 0f;
            Destroy(this.gameObject);
        }
    }
}
