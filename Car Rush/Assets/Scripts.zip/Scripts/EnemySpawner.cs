using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject[] _enemyPrefabs;
    [SerializeField]
    private float _maxEnemyLeft;
    [SerializeField]
    private float _maxEnemyRight;
    [SerializeField]
    private float delayTimer = 1f;
    float timer;

    // Start is called before the first frame update
    void Start()
    {
        timer = delayTimer;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if(timer <= 0)
        {
            Vector3 spawnpos = new Vector3(Random.Range(_maxEnemyLeft, _maxEnemyRight), transform.position.y, transform.position.z);
            int randomIndex = Random.Range(0, 2);
            Instantiate(_enemyPrefabs[randomIndex], spawnpos, transform.rotation);
            timer = delayTimer;
        }
    }
}
